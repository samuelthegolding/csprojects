import java.io.File;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.ArrayList;

public class LadderGame {
    ArrayList<ArrayList<String>> wordGrids;

    public LadderGame(String dictionaryFile) {
        this.wordGrids = readDictionary(dictionaryFile);
    }

    public void play(String start, String end) {
        if (start.length() != end.length()) {
            System.out.println("Start and end Words need to be the same length");
            return;
        }
        Queue<WordInfo> queue = new Queue<>();
        queue.enqueue(new WordInfo(start, 0));
        double enqueues = 0;

        System.out.print(start + " -> " + end);
        while (!queue.isEmpty()) {
            WordInfo active = queue.dequeue();
            String activeWord = active.getWord();

            if (activeWord.equals(end)) {

                System.out.printf(" : Moves %d : [%s], Total Enqueues: %d%n",
                        active.getMoves(), active.getHistory(), (int) enqueues);
                return;
            }

            for (String oneLetterAway : oneAway(activeWord, true)) {
                if (!active.getHistory().contains(oneLetterAway)) {
                    enqueues++;
                    queue.enqueue(
                            new WordInfo(
                                    oneLetterAway,
                                    active.getMoves() + 1,
                                    active.getHistory() + " " + oneLetterAway
                            )
                    );
                }
            }
        }
        System.out.println(" No Ladder was found :(");

    }

    public ArrayList<String> oneAway(String word, boolean withRemoval) {
        ArrayList<String> oneAwayWords = new ArrayList<>();
        int wordLen = word.length();
        ArrayList<String> sameLength = wordGrids.get(wordLen);

        for (String oneAway : sameLength) {
            if (diff(word, oneAway) == 1) {
                oneAwayWords.add(oneAway);
            }
        }
        if (withRemoval) {
            sameLength.removeAll(oneAwayWords);
        }

        return oneAwayWords;
    }

    public void listWords(int length, int howMany) {
        for (int i = 0; i < howMany; i++) {
            String word = wordGrids.get(length).get(i);
            System.out.println(word);
        }
    }

    /*
        Reads a list of words from a file, putting all words of the same length into the same array.
     */
    private ArrayList<ArrayList<String>> readDictionary(String dictionaryFile) {
        File file = new File(dictionaryFile);
        ArrayList<String> allWords = new ArrayList<>();

        // Track the longest word, because that tells us how big to make the array.
        int longestWord = 0;
        try (Scanner input = new Scanner(file)) {
            //
            // Start by reading all the words into memory.
            while (input.hasNextLine()) {
                String word = input.nextLine().toLowerCase();
                allWords.add(word);
                longestWord = Math.max(longestWord, word.length());
            }

            ArrayList<ArrayList<String>> wordGrids = new ArrayList<>(longestWord);
            for (int i = 0; i < longestWord + 1; i++) {
                wordGrids.add(new ArrayList<>());
            }
            for (String currentWord : allWords) {
                wordGrids.get(currentWord.length()).add(currentWord);
            }

            return wordGrids;
        } catch (java.io.IOException ex) {
            System.out.println("An error occurred trying to read the dictionary: " + ex);
        }
        return null;
    }

    private int diff(String word1, String word2) {
        int numDiff = 0;
        if (word1.equalsIgnoreCase(word2)) {
            return 0;
        } else if (word1.length() == word2.length()) {
            for (int i = 0; i < word1.length(); i++) {
                if (word1.charAt(i) != word2.charAt(i)) {
                    numDiff++;
                }
            }
        }
        return numDiff;
    }
}